### Bower

	$ npm install -g bower
	$ bower i

### Gulp

	$ npm install -g gulp
	$ npm install -g less
	$ npm i

### Usage

	$ gulp less